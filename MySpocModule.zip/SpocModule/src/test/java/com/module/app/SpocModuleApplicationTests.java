package com.module.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpocModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
