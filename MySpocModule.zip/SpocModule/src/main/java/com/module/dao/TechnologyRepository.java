package com.module.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.module.models.Technology;

@Repository
public interface TechnologyRepository extends CrudRepository<Technology,Integer>{

}
