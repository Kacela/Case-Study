package com.module.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.module.service.SpocService;

@Controller
public class SpocMainController {

	@Autowired
	private SpocService spocService;

		@RequestMapping("/spocmain")
		public String init(HttpServletRequest req) {
		req.setAttribute("requests",spocService.findAllRequests());
		req.setAttribute("rooms",spocService.findAllRooms());
		req.setAttribute("trainers",spocService.findAllTrainers());
		return "index";
	}
	
}