package com.module.models;


import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;


@SuppressWarnings("serial")
@Entity(name="trainer")
public class Trainer implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int trainer_id;
	
	@Column
	private String trainer_name;	
	private int technology_id;
	private boolean trainer_status;
	
	@OneToMany
	@JoinColumn(name="technology_id",referencedColumnName="technology_id")
	
	private List<Technology> technology;	
		
	public List<Technology> getTechnology() {
		return technology;
	}
	
	public int getTrainer_id() {
		return trainer_id;
	}
	public void setTrainer_id(int trainer_id) {
		this.trainer_id = trainer_id;
	}
	public String getTrainer_name() {
		return trainer_name;
	}
	public void setTrainer_name(String trainer_name) {
		this.trainer_name = trainer_name;
	}
	public int getTechnology_id() {
		return technology_id;
	}
	public void setTechnology_id(int technology_id) {
		this.technology_id = technology_id;
	}
	public boolean isTrainer_status() {
		return trainer_status;
	}
	public void setTrainer_status(boolean trainer_status) {
		this.trainer_status = trainer_status;
	}
	
	

	
	
	
}
