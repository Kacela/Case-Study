package com.module.models;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity(name="room")
public class Room {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int room_id;
	
	@Column
	private int room_no;	
	private boolean room_status;
	
	public int getRoom_id() {
		return room_id;
	}
	public void setRoom_id(int room_id) {
		this.room_id = room_id;
	}
	public int getRoom_no() {
		return room_no;
	}
	public void setRoom_no(int room_no) {
		this.room_no = room_no;
	}
	public boolean isRoom_status() {
		return room_status;
	}
	public void setRoom_status(boolean room_status) {
		this.room_status = room_status;
	}

	
	
	
}
