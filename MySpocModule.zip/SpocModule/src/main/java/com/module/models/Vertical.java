package com.module.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="vertical")
public class Vertical {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int vertical_id;
	
	private String vertical_name;

	public int getVertical_id() {
		return vertical_id;
	}

	public void setVertical_id(int vertical_id) {
		this.vertical_id = vertical_id;
	}

	public String getVertical_name() {
		return vertical_name;
	}

	public void setVertical_name(String vertical_name) {
		this.vertical_name = vertical_name;
	}
}
