package com.module;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan({"com.module"})
public class SpocModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpocModuleApplication.class, args);
	}

}
