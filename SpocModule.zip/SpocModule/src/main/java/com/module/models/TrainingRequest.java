package com.module.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="training_request")
public class TrainingRequest {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int request_id;
	
	@Column
	private int vertical_id;	
	private int technology_id;

	public int getRequest_id() {
		return request_id;
	}

	public void setRequest_id(int request_id) {
		this.request_id = request_id;
	}

	public int getVertical_id() {
		return vertical_id;
	}

	public void setVertical_id(int vertical_id) {
		this.vertical_id = vertical_id;
	}

	public int getTechnology_id() {
		return technology_id;
	}

	public void setTechnology_id(int technology_id) {
		this.technology_id = technology_id;
	}
	
}
