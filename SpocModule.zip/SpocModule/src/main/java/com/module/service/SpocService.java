package com.module.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.module.dao.SpocRepository;
import com.module.models.TrainingRequest;


@Service
public class SpocService {
	
	@Autowired
	private SpocRepository spocRepository;
	
	public Collection<TrainingRequest> findAllRequests(){
	List<TrainingRequest> requests = new ArrayList<>();
	Iterable<TrainingRequest> requestList = spocRepository.findAll();
	requestList.forEach(requests::add);
	return requests;
	}
}
