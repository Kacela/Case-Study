package com.module.controller.rest;

import java.util.Collection;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.module.models.TrainingRequest;
import com.module.service.SpocService;

@RestController
public class SpocRestController {

	@Autowired
	private SpocService spocService;
	
	@RequestMapping("/")
	public String home() {
		
		return "Welcome to the homepage";
	}
	
	@RequestMapping("/requests")
	public Collection<TrainingRequest> getAllRequests(){
		return spocService.findAllRequests();
	}
}
