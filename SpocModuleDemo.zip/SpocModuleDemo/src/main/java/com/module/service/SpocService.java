package com.module.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.module.dao.RoomRepository;
import com.module.dao.TrainerRepository;
import com.module.dao.TrainingRequestRepository;
import com.module.models.Room;
import com.module.models.Trainer;
import com.module.models.TrainingRequest;


@Service
public class SpocService {
	List<Trainer> trainers;
	
	@Autowired
	private TrainingRequestRepository trainingRequestRepository;
	
	public List<TrainingRequest> findAllRequests(){
	List<TrainingRequest> requests = new ArrayList<>();
	Iterable<TrainingRequest> requestList = trainingRequestRepository.findAll();
	requestList.forEach(requests::add);
	return requests;
	}
	
	@Autowired
	private RoomRepository roomRepository;
	
	public List<Room> findAllRooms(){
	List<Room> rooms = new ArrayList<>();
	Iterable<Room> roomList = roomRepository.findAll();
	roomList.forEach(rooms::add);
	return rooms;
	}
	
	@Autowired
	private TrainerRepository trainerRepository;
	
	public List<Trainer> findAllTrainers(){
	List<Trainer> trainers = new ArrayList<>();
	Iterable<Trainer> trainerList = trainerRepository.findAll();
	trainerList.forEach(trainers::add);
	return trainers;
	}

	/*
	 * public List<Trainer> findByTechnologyId(Integer technology_id) { return
	 * trainerRepository.findByTechnologyId(technology_id); }
	 */
	/*
	 * public Trainer getTrainer(int technologyId) { return
	 * trainers.stream().filter(t->t.getTechnologyId()==technologyId).findFirst().
	 * get(); }
	 */
	
	public List<Trainer> findByTechnologyId(int technologyId) { 
		return trainerRepository.findByTechnologyId(technologyId); 
	}

}
