package com.module.models;

import java.util.List;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;


@Entity(name="training_request")
public class TrainingRequest implements  Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="request_id")
	private int requestId;
	
	@Column(name="vertical_id")
	private int verticalId;	
	
	@Column(name="technology_id")
	private int technologyId;
	
	@Column(name="request_status")
	private int requestStatus;
	

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public int getVerticalId() {
		return verticalId;
	}

	public void setVerticalId(int verticalId) {
		this.verticalId = verticalId;
	}

	@OneToMany
	@JoinColumn(name="vertical_id",referencedColumnName="vertical_id")
	private List<Vertical> vertical;
	
	public List<Vertical> getVertical() {
		return vertical;
	}

	
	public int getTechnologyId() {
		return technologyId;
	}

	public void setTechnologyId(int technologyId) {
		this.technologyId = technologyId;
	}

	@OneToMany
	@JoinColumn(name="technology_id",referencedColumnName="technology_id")
	private List<Technology> technology;
	
	
	public List<Technology> getTechnology() {
		return technology;
	}

	public int getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(int requestStatus) {
		this.requestStatus = requestStatus;
	}
	

	
	

		
		
}
