package com.module.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="vertical")
public class Vertical {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="vertical_id")
	private int verticalId;
	
	@Column(name="vertical_name")
	private String verticalName;

	public int getVerticalId() {
		return verticalId;
	}

	public void setVerticalId(int verticalId) {
		this.verticalId = verticalId;
	}

	public String getVerticalName() {
		return verticalName;
	}

	public void setVerticalName(String verticalName) {
		this.verticalName = verticalName;
	}


}
