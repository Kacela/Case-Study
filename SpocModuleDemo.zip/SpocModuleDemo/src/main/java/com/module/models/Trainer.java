package com.module.models;


import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;


@SuppressWarnings("serial")
@Entity(name="trainer")
public class Trainer implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="trainer_id")
	private int trainerId;
	
	@Column(name="trainer_name")
	private String trainerName;
	
	@Column(name="technology_id")
	private int technologyId;
	
	@Column(name="trainer_status")
	private boolean trainerStatus;
	
	@OneToMany
	@JoinColumn(name="technology_id",referencedColumnName="technology_id")
	
	private List<Technology> technology;	
		
	public List<Technology> getTechnology() {
		System.out.print(technology);
		return technology;
	}

	public int getTrainerId() {
		return trainerId;
	}

	public void setTrainerId(int trainerId) {
		this.trainerId = trainerId;
	}

	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}

	public int getTechnologyId() {
		return technologyId;
	}

	public void setTechnologyId(int technologyId) {
		this.technologyId = technologyId;
	}

	public boolean isTrainerStatus() {
		return trainerStatus;
	}

	public void setTrainerStatus(boolean trainerStatus) {
		this.trainerStatus = trainerStatus;
	}
	
	

	
	
	
}
