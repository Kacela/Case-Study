package com.module.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.module.models.Trainer;

@Repository
public interface TrainerRepository extends CrudRepository<Trainer,Integer>{

	@Query(value ="SELECT * FROM Trainer  WHERE technology_id = ?1",nativeQuery = true)
	List<Trainer> findByTechnologyId(int technologyId);
	//public List<Trainer> findByTechnologyId(int technology_id);
}
