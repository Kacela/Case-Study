package com.module.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.module.models.TrainingRequest;

@Repository
public interface TrainingRequestRepository extends CrudRepository<TrainingRequest,Integer>{

}
