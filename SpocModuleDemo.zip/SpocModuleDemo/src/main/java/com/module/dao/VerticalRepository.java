package com.module.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.module.models.Vertical;

@Repository
public interface VerticalRepository extends CrudRepository<Vertical,Integer>{

}
