package com.module.controller;


import java.util.List;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.module.models.Trainer;
import com.module.service.SpocService;

@Controller
public class SpocMainController {

		@Autowired
		private SpocService spocService;

		@RequestMapping("/spocmain")
		public String init(HttpServletRequest req) {
		req.setAttribute("requests",spocService.findAllRequests());
		req.setAttribute("rooms",spocService.findAllRooms());
		req.setAttribute("trainers",spocService.findAllTrainers());
		return "index";
	}
	/*
	 * 
	 * public String demo (@PathVariable("technology_name") String techname, Model
	 * map) { map.addAttribute("msg", techname); return "index2"; }
	 */
		
		
//		@RequestMapping("/assign/{technologyId}")
//		public List<Trainer> findByTechnologyId(@PathVariable int technologyId) {
//			return spocService.findByTechnologyId(technologyId) ;
//			
//		}
		
}