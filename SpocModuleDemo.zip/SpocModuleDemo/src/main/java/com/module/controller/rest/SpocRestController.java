package com.module.controller.rest;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.module.models.Trainer;
import com.module.models.TrainingRequest;
import com.module.service.SpocService;

@RestController
public class SpocRestController {

	@Autowired
	private SpocService spocService;
	
	@RequestMapping("/")
	public String home() {
		
		return "Welcome to the homepage";
	}
	
	@RequestMapping("/requests")
	public Collection<TrainingRequest> getAllRequests(){
		return spocService.findAllRequests();
	}
	
	@RequestMapping("/assign/{technologyId}")
	public List<Trainer> findByTechnologyId(@PathVariable int technologyId) {
		return spocService.findByTechnologyId(technologyId) ;
		
	}
}
